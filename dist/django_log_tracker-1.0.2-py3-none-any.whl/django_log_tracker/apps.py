from django.apps import AppConfig


class DjangoLogTrackerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_log_tracker'
